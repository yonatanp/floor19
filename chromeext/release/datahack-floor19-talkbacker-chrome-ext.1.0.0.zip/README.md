Talkbacker Chrome Extension
===========================

The extension that talks back on ynet articles - so you don't have to!

Because it takes way too much effort to misspell misogynistic messages.